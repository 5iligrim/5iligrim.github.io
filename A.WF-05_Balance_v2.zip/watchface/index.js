﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let count_down_img = ''
        let normal_image_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_spo2_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_distance_text_text_img = ''

		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
	
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {	
            normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);				
          };
          if (zona1_num == 1) {
            normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);	
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);	
            normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);				
          };	  
		}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_moon_pointer_progress_img_pointer = ''
        let normal_moon_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_high_TextCircle = new Array(4);
        let normal_temperature_high_TextCircle_ASCIIARRAY = new Array(10);
        let normal_temperature_high_TextCircle_img_width = 23;
        let normal_temperature_high_TextCircle_img_height = 71;
        let normal_temperature_high_TextCircle_unit = null;
        let normal_temperature_high_TextCircle_unit_width = 69;
        let normal_temperature_high_TextCircle_dot_width = 15;
        let normal_temperature_low_TextCircle = new Array(4);
        let normal_temperature_low_TextCircle_ASCIIARRAY = new Array(10);
        let normal_temperature_low_TextCircle_img_width = 23;
        let normal_temperature_low_TextCircle_img_height = 71;
        let normal_temperature_low_TextCircle_unit = null;
        let normal_temperature_low_TextCircle_unit_width = 69;
        let normal_temperature_low_TextCircle_dot_width = 15;
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 23;
        let normal_calorie_TextCircle_img_height = 71;
        let normal_calorie_TextCircle_unit = null;
        let normal_calorie_TextCircle_unit_width = 77;
        let normal_fat_burning_TextCircle = new Array(3);
        let normal_fat_burning_TextCircle_ASCIIARRAY = new Array(10);
        let normal_fat_burning_TextCircle_img_width = 23;
        let normal_fat_burning_TextCircle_img_height = 71;
        let normal_fat_burning_TextCircle_unit = null;
        let normal_fat_burning_TextCircle_unit_width = 61;
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 23;
        let normal_heart_rate_TextCircle_img_height = 71;
        let normal_heart_rate_TextCircle_unit = null;
        let normal_heart_rate_TextCircle_unit_width = 68;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 23;
        let normal_step_TextCircle_img_height = 71;
        let normal_step_TextCircle_unit = null;
        let normal_step_TextCircle_unit_width = 56;
        let normal_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'icon_sun.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -75,
              end_angle: 75,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'icon_moon.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -75,
              end_angle: 75,
              invalid_visible: false,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_for_sun-moon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 107,
              image_array: ["moon_00.png","moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_high_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 255,
              // angle: 148,
              // char_space_angle: 1,
              // unit: 'ei_max.png',
              // dot_image: 'num_minus.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_temperature_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_temperature_high_TextCircle_img_width / 2,
                pos_y: 240 + 184,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_temperature_high_TextCircle_unit_width / 2,
              pos_y: 240 + 184,
              src: 'ei_max.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_temperature_low_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 255,
              // angle: 219,
              // char_space_angle: 1,
              // unit: 'ei_min.png',
              // dot_image: 'num_minus.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_low_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_temperature_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_temperature_low_TextCircle_img_width / 2,
                pos_y: 240 + 184,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_temperature_low_TextCircle_unit_width / 2,
              pos_y: 240 + 184,
              src: 'ei_min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 424,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_gradus_1.png',
              unit_tc: 'num_gradus_1.png',
              unit_en: 'num_gradus_1.png',
              negative_image: 'num_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 345,
              image_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 320,
              y: 320,
              image_array: ["w_d_1.png","w_d_2.png","w_d_3.png","w_d_4.png","w_d_5.png","w_d_6.png","w_d_7.png","w_d_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 350,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 130,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data_proc.png',
              unit_tc: 'data_proc.png',
              unit_en: 'data_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 277,
              month_startY: 300,
              month_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              month_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              month_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 300,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'data_tchk.png',
              day_unit_tc: 'data_tchk.png',
              day_unit_en: 'data_tchk.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 300,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 186,
              // angle: -93,
              // char_space_angle: -1,
              // unit: 'ei_cal.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 - 257,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_calorie_TextCircle_unit_width / 2,
              pos_y: 240 - 257,
              src: 'ei_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_fat_burning_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 185,
              // angle: 88,
              // char_space_angle: -1,
              // unit: 'ei_burning.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_fat_burning_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_fat_burning_TextCircle_img_width / 2,
                pos_y: 240 - 256,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_fat_burning_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_fat_burning_TextCircle_unit_width / 2,
              pos_y: 240 - 256,
              src: 'ei_burning.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_fat_burning_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 186,
              // angle: 28,
              // char_space_angle: -1,
              // unit: 'ei_puls.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 257,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_heart_rate_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_heart_rate_TextCircle_unit_width / 2,
              pos_y: 240 - 257,
              src: 'ei_puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 186,
              // angle: -32,
              // char_space_angle: -1,
              // unit: 'ei_steps.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 - 257,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_step_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_step_TextCircle_unit_width / 2,
              pos_y: 240 - 257,
              src: 'ei_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 99,
              hour_startY: 160,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 270,
              minute_startY: 160,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 220,
              second_startY: 185,
              second_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 118,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data_proc.png',
              unit_tc: 'data_proc.png',
              unit_en: 'data_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 272,
              month_startY: 305,
              month_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              month_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              month_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 305,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'data_tchk.png',
              day_unit_tc: 'data_tchk.png',
              day_unit_en: 'data_tchk.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 305,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 126,
              hour_startY: 161,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 239,
              minute_startY: 186,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Связь Потеряна,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Связь Восстановлена,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Связь Потеряна"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Связь Восстановлена"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 321,
              y: 322,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 360,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'timer.png',
              normal_src: 'timer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 98,
              y: 325,
              w: 42,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'but_telephon_on.png',
              normal_src: 'but_telephon_off.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

count_down_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 236,
			  w: 66,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              dot_image:'data_tr.png',
			  invalid_image:'data_tr.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_data_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 198,
              image_array: ["moon_00.png","moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 78,
              image_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 119,
              font_array: ["sml_num_0.png","sml_num_1.png","sml_num_2.png","sml_num_3.png","sml_num_4.png","sml_num_5.png","sml_num_6.png","sml_num_7.png","sml_num_8.png","sml_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 362,
              font_array: ["sml_num_0.png","sml_num_1.png","sml_num_2.png","sml_num_3.png","sml_num_4.png","sml_num_5.png","sml_num_6.png","sml_num_7.png","sml_num_8.png","sml_num_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 363,
              font_array: ["sml_num_0.png","sml_num_1.png","sml_num_2.png","sml_num_3.png","sml_num_4.png","sml_num_5.png","sml_num_6.png","sml_num_7.png","sml_num_8.png","sml_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 243,
              font_array: ["sml_num_0.png","sml_num_1.png","sml_num_2.png","sml_num_3.png","sml_num_4.png","sml_num_5.png","sml_num_6.png","sml_num_7.png","sml_num_8.png","sml_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 243,
              font_array: ["sml_num_0.png","sml_num_1.png","sml_num_2.png","sml_num_3.png","sml_num_4.png","sml_num_5.png","sml_num_6.png","sml_num_7.png","sml_num_8.png","sml_num_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 125,
              font_array: ["sml_num_0.png","sml_num_1.png","sml_num_2.png","sml_num_3.png","sml_num_4.png","sml_num_5.png","sml_num_6.png","sml_num_7.png","sml_num_8.png","sml_num_9.png"],
              padding: false,
              h_space: -3,
              dot_image: 'sml_num_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185, //x кнопки
              y: 375, //y кнопки
              text: '',
              w: 111, //ширина кнопки
              h: 37, //высота кнопки
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                click_zona1();},
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);

            normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            // end user_script_end.js

            let screenType = hmSetting.getScreenType();
            //#region text_update
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let temperature_high_temp = -100;
              if (forecastData.count > 0) {
                temperature_high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text circle temperature_high_forecastData');
              let temperatureHigh = undefined;
              let normal_temperature_high_circle_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                normal_temperature_high_circle_string = String(temperature_high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 328;
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_temperature_high_circle_string.length > 0 && normal_temperature_high_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_temperature_high_TextCircle_img_angle = 0;
                  let normal_temperature_high_TextCircle_dot_img_angle = 0;
                  let normal_temperature_high_TextCircle_unit_angle = 0;
                  normal_temperature_high_TextCircle_img_angle = toDegree(Math.atan2(normal_temperature_high_TextCircle_img_width/2, 255));
                  normal_temperature_high_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_temperature_high_TextCircle_dot_width/2, 255));
                  normal_temperature_high_TextCircle_unit_angle = toDegree(Math.atan2(normal_temperature_high_TextCircle_unit_width/2, 255));
                  // alignment = CENTER_H
                  let normal_temperature_high_TextCircle_angleOffset = normal_temperature_high_TextCircle_img_angle * (normal_temperature_high_circle_string.length - 1);
                  normal_temperature_high_TextCircle_angleOffset = normal_temperature_high_TextCircle_angleOffset + 1 * (normal_temperature_high_circle_string.length - 1) / 2;
                  normal_temperature_high_TextCircle_angleOffset = normal_temperature_high_TextCircle_angleOffset + (normal_temperature_high_TextCircle_img_angle + normal_temperature_high_TextCircle_unit_angle + 1) / 2;
                  normal_temperature_high_TextCircle_angleOffset = -normal_temperature_high_TextCircle_angleOffset;
                  char_Angle -= normal_temperature_high_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_temperature_high_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_temperature_high_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_high_TextCircle_img_width / 2);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.SRC, normal_temperature_high_TextCircle_ASCIIARRAY[charCode]);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_temperature_high_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_temperature_high_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_high_TextCircle_dot_width / 2);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.SRC, 'num_minus.png');
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_temperature_high_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_temperature_high_TextCircle_unit_angle;
                  normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let temperature_low_temp = -100;
              if (forecastData.count > 0) {
                temperature_low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text circle temperature_low_forecastData');
              let temperatureLow = undefined;
              let normal_temperature_low_circle_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                normal_temperature_low_circle_string = String(temperature_low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 399;
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_temperature_low_circle_string.length > 0 && normal_temperature_low_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_temperature_low_TextCircle_img_angle = 0;
                  let normal_temperature_low_TextCircle_dot_img_angle = 0;
                  let normal_temperature_low_TextCircle_unit_angle = 0;
                  normal_temperature_low_TextCircle_img_angle = toDegree(Math.atan2(normal_temperature_low_TextCircle_img_width/2, 255));
                  normal_temperature_low_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_temperature_low_TextCircle_dot_width/2, 255));
                  normal_temperature_low_TextCircle_unit_angle = toDegree(Math.atan2(normal_temperature_low_TextCircle_unit_width/2, 255));
                  // alignment = CENTER_H
                  let normal_temperature_low_TextCircle_angleOffset = normal_temperature_low_TextCircle_img_angle * (normal_temperature_low_circle_string.length - 1);
                  normal_temperature_low_TextCircle_angleOffset = normal_temperature_low_TextCircle_angleOffset + 1 * (normal_temperature_low_circle_string.length - 1) / 2;
                  normal_temperature_low_TextCircle_angleOffset = normal_temperature_low_TextCircle_angleOffset + (normal_temperature_low_TextCircle_img_angle + normal_temperature_low_TextCircle_unit_angle + 1) / 2;
                  normal_temperature_low_TextCircle_angleOffset = -normal_temperature_low_TextCircle_angleOffset;
                  char_Angle -= normal_temperature_low_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_temperature_low_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_temperature_low_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_low_TextCircle_img_width / 2);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.SRC, normal_temperature_low_TextCircle_ASCIIARRAY[charCode]);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_temperature_low_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_temperature_low_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_low_TextCircle_dot_width / 2);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.SRC, 'num_minus.png');
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_temperature_low_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_temperature_low_TextCircle_unit_angle;
                  normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -93;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  let normal_calorie_TextCircle_unit_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 186));
                  normal_calorie_TextCircle_unit_angle = toDegree(Math.atan2(normal_calorie_TextCircle_unit_width/2, 186));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + -1 * (normal_calorie_circle_string.length - 1) / 2;
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + (normal_calorie_TextCircle_img_angle + normal_calorie_TextCircle_unit_angle + -1) / 2;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_calorie_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_calorie_TextCircle_unit_angle;
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle fat_burning_FAT_BURRING');
              let valueFatBurning = fat_burning.current;
              let normal_fat_burning_circle_string = parseInt(valueFatBurning).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_fat_burning_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 88;
                if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && normal_fat_burning_circle_string.length > 0 && normal_fat_burning_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_fat_burning_TextCircle_img_angle = 0;
                  let normal_fat_burning_TextCircle_dot_img_angle = 0;
                  let normal_fat_burning_TextCircle_unit_angle = 0;
                  normal_fat_burning_TextCircle_img_angle = toDegree(Math.atan2(normal_fat_burning_TextCircle_img_width/2, 185));
                  normal_fat_burning_TextCircle_unit_angle = toDegree(Math.atan2(normal_fat_burning_TextCircle_unit_width/2, 185));
                  // alignment = CENTER_H
                  let normal_fat_burning_TextCircle_angleOffset = normal_fat_burning_TextCircle_img_angle * (normal_fat_burning_circle_string.length - 1);
                  normal_fat_burning_TextCircle_angleOffset = normal_fat_burning_TextCircle_angleOffset + -1 * (normal_fat_burning_circle_string.length - 1) / 2;
                  normal_fat_burning_TextCircle_angleOffset = normal_fat_burning_TextCircle_angleOffset + (normal_fat_burning_TextCircle_img_angle + normal_fat_burning_TextCircle_unit_angle + -1) / 2;
                  char_Angle -= normal_fat_burning_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_fat_burning_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_fat_burning_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_fat_burning_TextCircle_img_width / 2);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.SRC, normal_fat_burning_TextCircle_ASCIIARRAY[charCode]);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_fat_burning_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_fat_burning_TextCircle_unit_angle;
                  normal_fat_burning_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_fat_burning_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 28;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  let normal_heart_rate_TextCircle_unit_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 186));
                  normal_heart_rate_TextCircle_unit_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_unit_width/2, 186));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + -1 * (normal_heart_rate_circle_string.length - 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + (normal_heart_rate_TextCircle_img_angle + normal_heart_rate_TextCircle_unit_angle + -1) / 2;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_heart_rate_TextCircle_unit_angle;
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -32;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  let normal_step_TextCircle_unit_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 186));
                  normal_step_TextCircle_unit_angle = toDegree(Math.atan2(normal_step_TextCircle_unit_width/2, 186));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + -1 * (normal_step_circle_string.length - 1) / 2;
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + (normal_step_TextCircle_img_angle + normal_step_TextCircle_unit_angle + -1) / 2;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_step_TextCircle_unit_angle;
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}